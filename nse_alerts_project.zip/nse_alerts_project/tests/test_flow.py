import os, sys, tempfile, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["DATA_DIR"] = tempfile.mkdtemp()
from nse_alerts import config, premarket, overnight


def items(n_a=40, n_b=300):
    a = [dict(symbol=f"STOCK{i}", prev_close=1234.5 + i, pivot=1250.0 + i, dist_pivot_pct=1.3 + i * 0.2, score=84 - i * 1.5,
              setup="Accumulation day" if i % 2 else "Volatility coil", tier="A", rank=i + 1) for i in range(n_a)]
    return a + [dict(symbol=f"B{i}", prev_close=100, pivot=101, dist_pivot_pct=1, score=50, setup="x", tier="B", rank=41 + i)
                for i in range(n_b)]


def test_morning_watchlist_is_top_five_ranked_with_scores_in_one_message():
    msgs = premarket.messages(dict(items=items(), gated=340, liquid=1600, last_session="2026-11-09"))
    assert len(msgs) == 1 and len(msgs[0]) < 1000
    t = msgs[0]
    ranks = re.findall(r"<b>#(\d+) (\w+)</b> · score (\d+)", t)
    assert [r[0] for r in ranks] == ["1", "2", "3", "4", "5"] and ranks[0][1] == "STOCK0" and ranks[0][2] == "84"
    assert "STOCK5" not in t and "B0" not in t and "Top 5 of 340 candidates" in t
    assert premarket.messages(dict(items=items(n_a=3), gated=3, liquid=9, last_session="x"))[0].count("score") == 4   # 3 stocks + header


def test_global_markets_message_is_short_with_no_footnote():
    chosen = [("S&P 500", "k1"), ("GIFT Nifty", "k2")]
    data = {"k1": {"last_price": 6010.0, "net_change": -24.0}, "k2": {"last_price": 25120.5, "net_change": 75.5}}
    t = overnight.build_text(chosen, data)
    assert t.startswith("🌍 <b>Global markets</b> · last session") and "S&P 500 6,010 (-0.4%)" in t
    assert "lag" not in t and "<i>" not in t and t.count("\n") == 1


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)
