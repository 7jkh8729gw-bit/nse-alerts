import gzip, json, os, sys, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["DATA_DIR"] = tempfile.mkdtemp()
from nse_alerts import overnight, config

INS = [
    {"segment": "GLOBAL_INDEX", "name": "GIFT NIFTY", "instrument_key": "GLOBAL_INDEX|SGX NIFTY", "trading_symbol": "GIFT NIFTY"},
    {"segment": "GLOBAL_INDEX", "name": "S&P/ASX 200", "instrument_key": "GLOBAL_INDEX|AXJO", "trading_symbol": "^AXJO"},
    {"segment": "GLOBAL_INDEX", "name": "S&P 500", "instrument_key": "GLOBAL_INDEX|^GSPC", "trading_symbol": "^GSPC"},
    {"segment": "GLOBAL_INDEX", "name": "DOW JONES", "instrument_key": "GLOBAL_INDEX|^DJI", "trading_symbol": "^DJI"},
    {"segment": "GLOBAL_INDEX", "name": "US Tech 100", "instrument_key": "GLOBAL_INDEX|^NDX", "trading_symbol": "^NDX"},
    {"segment": "GLOBAL_INDICATOR", "name": "Oil (Brent)", "instrument_key": "GLOBAL_INDICATOR|BZUSD", "trading_symbol": "BZUSD"},
]
DATA = {  # key styles differ on purpose: ':' form, instrument_token match, and an ohlc-only fallback
    "GLOBAL_INDEX:SGX NIFTY": {"last_price": 25120.5, "net_change": 75.5, "instrument_token": "GLOBAL_INDEX|SGX NIFTY"},
    "X1": {"last_price": 6010.0, "net_change": -24.0, "instrument_token": "GLOBAL_INDEX|^GSPC"},
    "GLOBAL_INDEX:^DJI": {"last_price": 44000.0, "ohlc": {"close": 44220.0}},
    "GLOBAL_INDICATOR:BZUSD": {"last_price": 71.35, "net_change": 0.0},
}


def test_pick_avoids_asx_lookalike():
    ch = dict(overnight.pick(INS))
    assert ch["S&P 500"] == "GLOBAL_INDEX|^GSPC"            # not S&P/ASX 200
    assert ch["GIFT Nifty"] == "GLOBAL_INDEX|SGX NIFTY" and "Nikkei" not in ch


def test_text_handles_all_response_shapes():
    txt = overnight.build_text(overnight.pick(INS), DATA)
    assert "GIFT Nifty 25,120 (+0.3%)" in txt            # net_change path
    assert "S&P 500 6,010 (-0.4%)" in txt                # matched via instrument_token
    assert "Dow 44,000 (-0.5%)" in txt                   # ohlc-close fallback
    assert "Brent 71.35 (+0.0%)" in txt
    assert "Nasdaq" not in txt                           # no quote -> silently skipped


def test_failures_never_raise():
    config.UPSTOX_ANALYTICS_TOKEN = "t"
    orig = overnight.requests.get
    def boom(*a, **k): raise RuntimeError("network down")
    overnight.requests.get = boom
    try:
        assert overnight.summary() == ""
    finally:
        overnight.requests.get = orig
    config.UPSTOX_ANALYTICS_TOKEN = ""
    assert overnight.summary() == ""                     # no token -> quiet no-op


def test_end_to_end_with_mocked_http():
    config.UPSTOX_ANALYTICS_TOKEN = "t"
    class R:
        def __init__(self, content=b"", js=None): self.content, self._js = content, js
        def raise_for_status(self): pass
        def json(self): return self._js
    def fake(url, **k):
        if url.endswith("global.json.gz"): return R(gzip.compress(json.dumps(INS).encode()))
        assert "/v2/market-quote/quotes" in url and "GLOBAL_INDEX|SGX NIFTY" in k["params"]["instrument_key"]
        return R(js={"status": "success", "data": DATA})
    orig = overnight.requests.get
    overnight.requests.get = fake
    try:
        out = overnight.summary()
    finally:
        overnight.requests.get = orig; config.UPSTOX_ANALYTICS_TOKEN = ""
    assert out.startswith("🌍") and "GIFT Nifty" in out and out.count("·") >= 2


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)
