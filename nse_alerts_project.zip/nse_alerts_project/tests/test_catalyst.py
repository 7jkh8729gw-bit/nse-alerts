import csv, os, sys, tempfile, time as real_time
from datetime import datetime, timedelta
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
os.environ["DATA_DIR"] = tempfile.mkdtemp()
import pandas as pd
import synth
from nse_alerts import config, catalyst, signals
from nse_alerts.signals import Bar, Ctx, Snap

IST = config.IST
DAY = datetime(2026, 11, 10, tzinfo=IST)                       # Tuesday
CTX = Ctx(symbol="AAA", token="111", tier="N", pivot=100, atr=2.0, atr_pct=2.0, avg_vol20=1_000_000, prev_close=100.0)


def f(minute_of_day):
    return signals.expected_cum_fraction(minute_of_day - 555)


def bar(h, m, o, hi, lo, c):
    return Bar(DAY.replace(hour=h, minute=m), o, hi, lo, c)


PREV = [bar(9, 30 + i, 101.0, 101.3, 100.9, 101.1) for i in range(12)]          # range high 101.3
GOOD = bar(9, 55, 101.2, 101.8, 101.1, 101.7)
TOTAL = 2.0 * 1_000_000 * f(9 * 60 + 56)                                       # total volume 2x normal


def ev(b=GOOD, prev=PREV, cum=TOTAL, vwap=100.9, orb=100.8, accel=5.0, mkt=0.1, n=0):
    return catalyst.evaluate_news(CTX, b, prev, Snap(b.c, cum, vwap, orb), accel, mkt, n)


def test_rules_one_by_one():
    d = ev()
    assert d.fire and d.level == 101.3 and d.entry == 101.7 and d.sl < 101.3 < d.entry
    risk = d.entry - d.sl
    assert abs((d.t1 - d.entry) / risk - 1.5) < 1e-9 and abs((d.t2 - d.entry) / risk - 3.0) < 1e-9
    cases = {
        "not moving yet": ev(bar(9, 55, 100.4, 100.9, 100.3, 100.8)),
        "already extended": ev(bar(9, 55, 107.0, 108.5, 106.9, 108.0)),
        "below range high": ev(bar(9, 55, 101.0, 101.25, 100.9, 101.2)),
        "breakout bar is red": ev(bar(9, 55, 101.9, 101.95, 101.4, 101.5)),
        "extended beyond entry zone": ev(bar(9, 55, 101.9, 102.6, 101.8, 102.5)),
        "below VWAP": ev(vwap=101.9),
        "total volume low": ev(cum=0.8 * 1_000_000 * f(9 * 60 + 56)),
        "volume pace low": ev(accel=2.0),
        "outside window": ev(bar(14, 45, 101.2, 101.8, 101.1, 101.7)),
        "market weak": ev(mkt=-1.2),
        "daily cap": ev(n=config.NEWS_MAX_ALERTS),
    }
    for reason, got in cases.items():
        assert not got.fire and got.reason == reason, (reason, got.reason)
    assert ev(prev=PREV[:3], orb=None).reason == "no range yet"
    # extension is judged against the stock's own normal daily range
    quiet = Ctx(symbol="QQQ", token="9", tier="N", pivot=100, atr=1.0, atr_pct=1.0, avg_vol20=1_000_000, prev_close=100.0)
    d = catalyst.evaluate_news(quiet, GOOD, PREV, Snap(GOOD.c, TOTAL, 100.9, 100.8), 5.0, 0.1, 0)
    assert not d.fire and d.reason == "extended vs normal daily range"                  # +1.7% on a 1% stock
    assert ev(vwap=99.0).reason == "stretched above VWAP"                               # 2.7% over VWAP on a 2% stock
    assert ev().metrics["ext_atr"] == 0.85 and ev().metrics["day_chg_pct"] == 1.7


def msg(token, price, t, cum, vwap=101.0):
    return {"_norm": True, "token": token, "price": price, "ts": t, "cum_vol": cum, "vwap": vwap, "day_open": 100.3}


CONTEXT = {"market": {"symbol": "NIFTYBEES", "token": "999", "prev_close": 100.0},
           "items": [dict(symbol=s, token=t, tier="N", pivot=100.0, atr=2.0, atr_pct=2.0, avg_vol20=1_000_000, prev_close=100.0)
                     for s, t in (("AAA", "111"), ("BBB", "222"))]}
WATCH = {"AAA": dict(cats=["Big order"], subject="Bagging/Receiving of orders/contracts", score=5.0)}


class Clock:
    def __init__(self): self.t = DAY.replace(hour=9, minute=15)
    def __call__(self): return self.t


def make(sent, tag, watch=WATCH):
    clk = Clock()
    e = catalyst.CatalystEngine(CONTEXT, dict(watch), send=lambda text, silent=False: sent.append(text), now_fn=clk,
                                state_path=os.path.join(config.DATA_DIR, f"{tag}.json"),
                                log_path=os.path.join(config.DATA_DIR, f"{tag}.csv"))
    return e, clk


def play(e, clk, tokens=("111", "222"), until=(9, 58), at_940=None):
    """09:15 opening range, quiet drift to 09:50, then a volume surge with price breaking out."""
    avg, base_pace, surge, t50 = 1_000_000, 1.8, 7.0, 9 * 60 + 50
    for minute in range(9 * 60 + 15, until[0] * 60 + until[1]):
        if minute < 9 * 60 + 30:
            price = 100.3 + 0.5 * (minute % 2)
        elif minute <= t50:
            price = 100.9 + 0.02 * (minute - 570)
        else:
            price = 101.35 + 0.1 * (minute - (t50 + 1))
        cum = base_pace * avg * f(minute) if minute <= t50 else base_pace * avg * f(t50) + surge * avg * (f(minute) - f(t50))
        if at_940 and minute == 9 * 60 + 40:
            at_940()
        for sec in (5, 35):
            clk.t = DAY.replace(hour=minute // 60, minute=minute % 60, second=sec)
            e.on_tick(msg("999", 100.1, clk.t, 5_000_000))
            for tok in tokens:
                e.on_tick(msg(tok, price, clk.t, cum))


def test_only_catalyst_stock_alerts_and_it_is_recorded():
    sent = []; e, clk = make(sent, "c1")
    play(e, clk)
    assert len(sent) == 1, sent                                           # BBB (same ticks, no news) stays silent
    t = sent[0]
    assert "BUY (News): AAA" in t and "Big order" in t and "Bagging/Receiving" in t
    assert "Entry zone" in t and "Stop" in t and "T1" in t and "volume pace" in t and "Not financial advice" not in t
    rows = list(csv.DictReader(open(os.path.join(config.DATA_DIR, "c1.csv"))))
    assert len(rows) == 1 and rows[0]["event"] == "ALERT" and rows[0]["tier"] == "N" and rows[0]["setup"] == "Big order"
    assert float(rows[0]["sl"]) < float(rows[0]["entry"]) < float(rows[0]["t1"])
    # restart: no duplicate
    sent2 = []; e2 = catalyst.CatalystEngine(CONTEXT, dict(WATCH), send=lambda x, silent=False: sent2.append(x), now_fn=clk,
                                             state_path=os.path.join(config.DATA_DIR, "c1.json"),
                                             log_path=os.path.join(config.DATA_DIR, "c1.csv"))
    play(e2, clk); assert not sent2


def test_news_arriving_mid_day_is_picked_up_without_resubscribing():
    sent = []; e, clk = make(sent, "c2", watch={})
    play(e, clk, tokens=("222",), at_940=lambda: e.set_watch({"BBB": dict(cats=["Results"], subject="Financial Results", score=4.0)}))
    assert len(sent) == 1 and "BUY (News): BBB" in sent[0] and "Results" in sent[0]
    sent = []; e, clk = make(sent, "c3", watch={})
    play(e, clk, tokens=("222",))                                          # never gets a catalyst -> never alerts
    assert not sent


def test_contexts_and_refresher():
    store = pd.concat([synth.make_symbol(f"S{i:03d}", seed=i, base=90 + i) for i in range(12)]
                      + [synth.make_symbol("NIFTYBEES", seed=99, base=250)], ignore_index=True)
    store["turnover_cr"] = store["volume"] * store["close"] / 1e7
    tmap = {s: f"NSE_EQ|{s}" for s in store["symbol"].unique()}
    c = catalyst.build_contexts(store, tmap, limit=8)
    assert len(c["items"]) == 8 and c["market"]["symbol"] == "NIFTYBEES"
    need = {"symbol", "token", "tier", "pivot", "atr", "atr_pct", "avg_vol20", "prev_close"}
    assert all(need <= set(i) and i["tier"] == "N" and i["atr"] > 0 for i in c["items"])
    # background refresher updates what the engine watches (stubbed news source, 10:00 clock)
    sent = []; e, clk = make(sent, "c4", watch={})
    saved_now = config.now_ist; config.now_ist = lambda: DAY.replace(hour=10)
    try:
        catalyst.start_refresher(e, collect=lambda now: {"ok": True, "watch": {"AAA": dict(cats=["Buyback"], score=3.0)}}, every=0.05)
        for _ in range(40):
            if "AAA" in e.active: break
            real_time.sleep(0.05)
    finally:
        config.now_ist = saved_now
    assert "AAA" in e.active


def test_runs_inside_the_normal_supervisor():
    import test_supervisor as ts
    from nse_alerts import run_day
    st = ts.setup(lambda now: True)
    created = []
    def factory(c):
        e = catalyst.CatalystEngine(c, {}, send=lambda x, silent=False: None, now_fn=lambda: config.now_ist(),
                                    state_path=os.path.join(config.DATA_DIR, "c5.json"), log_path=os.path.join(config.DATA_DIR, "c5.csv"))
        created.append(e); return e
    assert run_day.run_session(ts.CTX, engine_factory=factory) == "done" and len(created) == 1 and created[0].ticks > 0


if __name__ == "__main__":
    for n, fn in list(globals().items()):
        if n.startswith("test_"):
            fn(); print("PASS", n)
