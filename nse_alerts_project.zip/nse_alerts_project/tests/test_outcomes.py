import csv, os, sys, tempfile
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["DATA_DIR"] = tempfile.mkdtemp()
os.environ["RESULTS_DIR"] = os.path.join(tempfile.mkdtemp(), "results")
from nse_alerts import config, outcomes, notify

DAY = "2026-11-06"      # a Friday


def candle(h, m, o, hi, lo, c, v=1000):
    return [f"{DAY}T{h:02d}:{m:02d}:00+05:30", o, hi, lo, c, v]


def series(spec, start=(10, 0)):
    rows, mins = [], start[0] * 60 + start[1]
    for i, (hi, lo, c) in enumerate(spec):
        t = mins + 1 + i
        rows.append(candle(t // 60, t % 60, c, hi, lo, c))
    return rows


E, SL, T1, T2 = 100.0, 98.0, 103.0, 106.0          # risk 2 -> T1 = 1.5R, T2 = 3R


def test_outcomes_follow_live_rules():
    o = outcomes.engine_outcome(series([(101, 99.5, 100.5), (107, 100, 106.5)]), "10:00", E, SL, T1, T2)
    assert o["outcome"] == "T2" and o["r"] == 3.0 and o["minutes_to_outcome"] == 2
    o = outcomes.engine_outcome(series([(100.5, 97.5, 98.5)]), "10:00", E, SL, T1, T2)
    assert o["outcome"] == "SL" and o["r"] == -1.0 and o["mae_r"] == -1.25
    o = outcomes.engine_outcome(series([(103.5, 100, 103), (104, 99.9, 100.5)]), "10:00", E, SL, T1, T2)
    assert o["outcome"] == "BE_STOP" and o["r"] == 0.0 and o["mfe_r"] == 2.0
    o = outcomes.engine_outcome(series([(103.5, 100, 103), (104.5, 101, 104)]), "10:00", E, SL, T1, T2)
    assert o["outcome"] == "EOD_after_T1" and o["r"] == 2.0
    o = outcomes.engine_outcome(series([(101, 99, 100), (101.5, 99.5, 101)]), "10:00", E, SL, T1, T2)
    assert o["outcome"] == "EOD" and o["r"] == 0.5
    o = outcomes.engine_outcome(series([(103.5, 97.5, 100)]), "10:00", E, SL, T1, T2)   # touches stop AND target
    assert o["outcome"] == "SL"
    assert outcomes.engine_outcome([], "10:00", E, SL, T1, T2)["outcome"] == "NO_DATA"


class FakeClient:
    def __init__(self, data): self.data = data
    def login(self): pass
    def candles(self, token, interval, start, end): return self.data.get(token, [])


HEADER = ["date", "time", "symbol", "tier", "event", "price", "entry", "sl", "t1", "t2", "r_multiple", "rvol", "score", "setup"]


def write_log(path, rows):
    with open(path, "w", newline="") as f:
        w = csv.writer(f); w.writerow(HEADER); w.writerows(rows)


def test_simple_summary_records_everything_and_sends_friday_extras():
    eng_log, news_log = outcomes.SOURCES[0][1], outcomes.SOURCES[1][1]
    write_log(eng_log, [[DAY, "10:00:00", "AAA", "A", "ALERT", 100, 100, 98, 103, 106, "", 2.1, 80, "coil"],
                        [DAY, "10:05:00", "AAA", "A", "T1", 103, "", "", "", "", 1.5, "", "", ""],     # not an ALERT: ignored
                        [DAY, "11:00:00", "CCC", "B", "ALERT", 100, 100, 98, 103, 106, "", 2.6, 60, "trend"]])
    write_log(news_log, [[DAY, "10:30:00", "BBB", "N", "ALERT", 100, 100, 98, 103, 106, "", 1.8, 5, "Big order"]])
    import json
    day_state = lambda sym, m: {"date": DAY, "alerted": [sym], "metrics": {sym: dict(m, time="10:00")}}
    json.dump(day_state("AAA", dict(day_chg_pct=1.2, atr_pct=2.0, ext_atr=0.6, vwap_atr=0.3, above_level_pct=0.4, from_open_pct=0.9)),
              open(outcomes.STATES["breakout"], "w"))
    json.dump(day_state("BBB", dict(day_chg_pct=3.0, atr_pct=2.0, ext_atr=1.5)), open(outcomes.STATES["news"], "w"))
    data = {"T_AAA": series([(101, 99.5, 100.5)] * 3 + [(107, 100, 106.5)]),                  # T2 (+3R)
            "T_BBB": series([(100.5, 97.5, 98.5)], start=(10, 30)),                           # stop-loss (-1R)
            "T_CCC": series([(101, 99.5, 100.5)] * 5, start=(11, 0))}                         # neither (+0.5R)
    from nse_alerts import broker
    broker.load_token_map = lambda force=False: {"AAA": "T_AAA", "BBB": "T_BBB", "CCC": "T_CCC"}
    sent, docs = [], []
    notify.send = lambda text, silent=False: sent.append(text)
    outcomes.send_document = lambda path, caption="": docs.append(os.path.basename(path)) or True
    out = outcomes.run(DAY, client=FakeClient(data))
    assert out["weekly"] is True and len(sent) == 1                                   # ONE message
    t = sent[0].replace("<b>", "").replace("</b>", "")
    assert "Day summary · Fri 06 Nov" in t
    assert "Breakout: 2 alerts · 1 target hit · 0 stop-loss · 1 neither (+3.2R)" in t, t
    assert "News: 1 alert · 0 target hit · 1 stop-loss · 0 neither (-1.0R)" in t, t
    assert "Total: 3 alerts · 1 target hit · 1 stop-loss · net +2.2R" in t, t
    assert "Since start (1 day)" in t and "Breakout 2 alerts" in t and "News 1 alert," in t
    assert docs == ["alert_results.csv"]
    rows = list(csv.DictReader(open(outcomes.RESULTS)))
    byk = {(r["system"], r["symbol"]): r for r in rows}
    assert byk[("breakout", "AAA")]["ext_atr"] == "0.6" and byk[("news", "BBB")]["ext_atr"] == "1.5"   # extension recorded
    assert byk[("breakout", "CCC")]["ext_atr"] == ""                                                    # not measured: left blank
    assert "Extension check: collecting data (2 alerts measured so far)" in t
    assert {(r["system"], r["symbol"], r["outcome"]) for r in rows} == {("breakout", "AAA", "T2"), ("breakout", "CCC", "EOD"), ("news", "BBB", "SL")}
    outcomes.run(DAY, send=False, client=FakeClient(data))                           # re-run: no duplicates
    assert len(list(csv.DictReader(open(outcomes.RESULTS)))) == 3


def test_extension_text_groups_outcomes():
    rows = [dict(ext_atr=str(e), r=str(r)) for e, r in [(0.3, 1.0), (0.4, 0.5), (0.7, 0.2), (0.8, -1.0), (1.0, -1.0), (1.1, -0.5), (None, 2.0)]
            if e is not None]
    t = outcomes.extension_text(rows)
    assert "under 0.5: 2 alerts, avg +0.75R" in t and "0.5-0.9: 2 alerts, avg -0.40R" in t and "0.9 and over: 2 alerts, avg -0.75R" in t
    assert "collecting data (3 alerts" in outcomes.extension_text(rows[:3])


def test_quiet_day_and_non_friday_have_no_extras():
    for _, p in outcomes.SOURCES:
        if os.path.exists(p): os.remove(p)
    sent, docs = [], []
    notify.send = lambda text, silent=False: sent.append(text)
    outcomes.send_document = lambda path, caption="": docs.append(path) or True
    out = outcomes.run("2026-11-09", client=None)                                    # Monday, no alerts, no broker login
    assert out["weekly"] is False and not docs and len(sent) == 1
    assert "No alerts today." in sent[0] and "Since start" not in sent[0]


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)
