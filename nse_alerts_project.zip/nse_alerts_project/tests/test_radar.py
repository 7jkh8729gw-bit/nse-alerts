import os, sys, tempfile, types
import time as real_time
from datetime import datetime, timedelta
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
os.environ["DATA_DIR"] = tempfile.mkdtemp()
import pandas as pd
import synth
from nse_alerts import config, radar, broker, notify, signals

IST = config.IST
DAY = datetime(2026, 11, 3, tzinfo=IST)           # a Tuesday
UNI = {"T1": dict(symbol="RELI", prev_close=100.0, avg_vol=1_000_000),
       "T2": dict(symbol="SLOW", prev_close=200.0, avg_vol=500_000)}


def tick(tok, price, h, m, cum, vwap=0.0, open_=None, s=10):
    t = DAY.replace(hour=h, minute=m, second=s)
    return {"_norm": True, "token": tok, "price": price, "ts": t, "cum_vol": cum, "vwap": vwap, "day_open": open_}


def make(sent, heads=lambda s: ["Reliance Q2 profit jumps 18% - Example News"]):
    clk = [DAY.replace(hour=9, minute=16, second=30)]
    r = radar.Radar(UNI, send=lambda text, silent=False: sent.append(text), now_fn=lambda: clk[0], headlines=heads,
                    state_path=os.path.join(os.environ["DATA_DIR"], f"rs{len(sent)}{real_time.time()}.json"))
    return r, clk


def test_gap_up_on_heavy_volume_fires_once():
    sent = []; r, clk = make(sent)
    clk[0] = DAY.replace(hour=9, minute=17)
    r.on_tick(tick("T1", 110.5, 9, 17, 400_000, vwap=109.0, open_=108.0))   # +10.5%, 40% of a normal day in 2 min
    assert len(sent) == 1 and "BIG MOVER: RELI" in sent[0] and "+10.5%" in sent[0] and "Example News" in sent[0]
    assert "circuit" in sent[0] and "not a buy signal" not in sent[0] and "opened +8.0%" in sent[0]
    r.on_tick(tick("T1", 111.0, 9, 18, 500_000))
    assert len(sent) == 1                                  # one alert per stock per day


def test_rejects_small_move_low_volume_and_stale():
    sent = []; r, clk = make(sent)
    clk[0] = DAY.replace(hour=10, minute=0)
    r.on_tick(tick("T1", 103.0, 10, 0, 900_000))           # +3%: too small
    r.on_tick(tick("T2", 215.0, 10, 0, 100_000))           # +7.5% but volume only ~0.7x normal
    yday = tick("T1", 120.0, 10, 0, 5_000_000); yday["ts"] -= timedelta(days=1)
    r.on_tick(yday)                                        # yesterday's snapshot
    early = tick("T1", 120.0, 9, 10, 5_000_000)            # pre-open, before 09:16
    r.on_tick(early)
    assert not sent, sent


def test_midday_move_needs_time_adjusted_volume():
    sent = []; r, clk = make(sent)
    clk[0] = DAY.replace(hour=12, minute=0)
    # at 12:00 (165 min in) ~52% of a day's volume is normal; 1.3M cum = ~2.5x -> not enough
    r.on_tick(tick("T1", 106.0, 12, 0, 1_300_000)); assert not sent
    # 1.8M cum = ~3.5x -> fires
    r.on_tick(tick("T1", 106.5, 12, 1, 1_800_000)); assert len(sent) == 1


def test_catalyst_tag_shown_in_alert():
    sent = []; r, clk = make(sent)
    clk[0] = DAY.replace(hour=9, minute=20)
    r.on_tick(tick("T2", 215.0, 9, 20, 300_000))
    assert len(sent) == 1 and "Catalyst: <b>Results</b>" in sent[0] and "Headlines" in sent[0]
    log_rows = open(radar.LOG_FILE).read()                              # recorded for the accuracy report
    assert "date,time,symbol,kind,price,chg,rv,accel,catalyst" in log_rows and "RELI,strong" in log_rows and "Results" in log_rows


def test_restart_does_not_repeat():
    sent = []; path = os.path.join(os.environ["DATA_DIR"], "rr.json")
    clk = DAY.replace(hour=9, minute=30)
    r = radar.Radar(UNI, send=lambda t, silent=False: sent.append(t), now_fn=lambda: clk, headlines=lambda s: ["Reliance Q2 results: profit jumps - X"], state_path=path)
    r.on_tick(tick("T1", 111.0, 9, 30, 600_000)); assert len(sent) == 1
    r2 = radar.Radar(UNI, send=lambda t, silent=False: sent.append(t), now_fn=lambda: clk, headlines=lambda s: ["Reliance Q2 results: profit jumps - X"], state_path=path)
    r2.on_tick(tick("T1", 112.0, 9, 31, 700_000)); assert len(sent) == 1


def test_universe_and_rss_parsing():
    store = pd.concat([synth.make_symbol(f"S{i:03d}", seed=i, base=90 + i) for i in range(30)], ignore_index=True)
    store["turnover_cr"] = store["volume"] * store["close"] / 1e7
    tmap = {f"S{i:03d}": f"NSE_EQ|INE{i:06d}" for i in range(28)}        # S028/S029 have no token
    uni = radar.build_universe(store, tmap, limit=10)
    assert len(uni) == 10 and all(v["avg_vol"] > 0 and v["prev_close"] > 0 for v in uni.values())
    assert all(k.startswith("NSE_EQ|") for k in uni)
    # (RSS freshness/relevance and failure handling are covered in test_fetch_headlines below)


# ---------------------------------------------------------------- early tier
def _f(minute_of_day):                         # expected cumulative volume fraction at a clock time
    return signals.expected_cum_fraction(minute_of_day - (9 * 60 + 15))


def run_early(sent, pace_before=2.0, window_mult=6.0, market=None, start=(10, 0), price_end=102.4, mk_chg=0.0):
    """10:00-10:10: volume at `pace_before`x normal, then the last 5 minutes at `window_mult`x normal pace."""
    clk = [DAY.replace(hour=start[0], minute=start[1])]
    mkt = {"token": "MKT", "prev_close": 100.0}
    r = radar.Radar(UNI, send=lambda text, silent=False: sent.append((text, silent)), now_fn=lambda: clk[0],
                    headlines=lambda s: ["Reliance bags Rs 5,000 crore order from Example Ltd - News"], market=mkt,
                    state_path=os.path.join(os.environ["DATA_DIR"], f"e{real_time.time()}.json"))
    base = start[0] * 60 + start[1]
    avg = UNI["T1"]["avg_vol"]
    for step in range(0, 21):                  # every 30 s for 10 minutes
        mins = step / 2
        m = base + mins
        if mins <= 5:
            cum = pace_before * avg * _f(m)
        else:
            cum = pace_before * avg * _f(base + 5) + window_mult * avg * (_f(m) - _f(base + 5))
        price = 100.0 + 0.5 + (price_end - 100.5) * (mins / 10)
        t = DAY.replace(hour=int(m // 60), minute=int(m % 60), second=int((m % 1) * 60))
        clk[0] = t
        r.on_tick({"_norm": True, "token": "MKT", "price": 100.0 * (1 + mk_chg / 100), "ts": t, "cum_vol": 1, "vwap": 0, "day_open": None})
        r.on_tick({"_norm": True, "token": "T1", "price": price, "ts": t, "cum_vol": cum, "vwap": 100.8, "day_open": 100.3})
    return r


def test_early_alert_on_accelerating_volume():
    sent = []; r = run_early(sent)
    texts = [t for t, _ in sent]
    assert len(texts) == 1 and "EARLY MOVER: RELI" in texts[0], texts
    m = __import__("re").search(r"<b>\+(\d\.\d)%</b> today", texts[0])
    assert m and 2.0 <= float(m.group(1)) < 3.0, texts[0]            # fires as soon as pace + move qualify
    assert "still early" in texts[0] and "last 5 min" in texts[0]
    assert "How far it has run" not in texts[0] and sent[0][1] is False   # early alerts are audible now


def test_early_blocked_without_acceleration_or_vs_market():
    sent = []; run_early(sent, window_mult=2.0);          assert not sent          # steady 2x, no acceleration
    sent = []; run_early(sent, window_mult=3.0);          assert not sent          # 3x pace: below the 4x requirement
    sent = []; run_early(sent, mk_chg=3.0);               assert not sent          # market +3%: stock not outperforming
    radar.EARLY_REL = 0.0                                                           # filter can be switched off
    try:
        sent = []; run_early(sent, mk_chg=3.0);           assert len(sent) == 1
    finally:
        radar.EARLY_REL = 1.0
    sent = []; run_early(sent, price_end=101.5);          assert not sent          # only +1.5%: below early threshold
    sent = []; run_early(sent, start=(14, 25));           assert not sent          # too late in the day for EARLY


def test_followup_once_when_early_name_runs_to_strong():
    sent = []; r = run_early(sent); assert len(sent) == 1
    t = DAY.replace(hour=10, minute=12)
    r.now_fn = lambda: t
    r.on_tick({"_norm": True, "token": "T1", "price": 105.3, "ts": t, "cum_vol": 3_000_000, "vwap": 102.0, "day_open": 100.3})
    follow = [x for x, _ in sent if "early alert price" in x]
    early_px = next(iter(r.state["early"].values()))
    since = (105.3 / early_px - 1) * 100
    assert len(follow) == 1 and "+5.3%" in follow[0] and f"{since:+.1f}%" in follow[0], sent
    r.on_tick({"_norm": True, "token": "T1", "price": 106.0, "ts": t, "cum_vol": 3_100_000, "vwap": 102.0, "day_open": 100.3})
    assert len([x for x, _ in sent if "early alert price" in x]) == 1 and len(sent) == 2   # no repeats, no 2nd BIG alert


# ---------------------------------------------------------------- catalyst gate
def test_classify_catalysts():
    yes = {
        "Reliance Q2 results: net profit jumps 18% YoY": "Results",
        "Infosys Q1 FY27 earnings beat estimates": "Results",
        "TCS announces bonus issue of shares": "Bonus / split",
        "XYZ board approves stock split": "Bonus / split",
        "Tata Steel to acquire ABC Ltd in Rs 500 crore deal": "Merger / deal",
        "Board clears merger of two subsidiaries": "Merger / deal",
        "L&T bags mega orders worth Rs 10,000 crore": "Big order",
        "Company wins Rs 800 crore contract from railways": "Big order",
        "XYZ announces share buyback at 15% premium": "Buyback",
        "Sun Pharma gets USFDA approval for new drug": "Approval",
        "Emcure Pharma shares soar 10% after Q2 results; check what brokerages recommend - Business Today": "Results",
    }
    for title, cat in yes.items():
        assert radar.classify(title) == cat, (title, radar.classify(title))
    for title in ["Q2 results preview: what to expect from Reliance", "Stocks to watch: Reliance, TCS, results today",
                  "Board meeting on Nov 7 to consider results", "Top gainers: Emcure, Sun Pharma, Q2 results",
                  "Stocks to watch today: Sensex, Nifty open higher", "Why is XYZ stock rising today?",
                  "XYZ share price target raised by brokerage", "Market wrap: banks lead gains"]:
        assert radar.classify(title) is None, title


def test_relevance_filter():
    assert radar.is_relevant("TATAMOTORS", "anything at all")            # long tickers: distinctive
    assert radar.is_relevant("LT", "L&T bags orders") and radar.is_relevant("ITC", "ITC results out")
    assert not radar.is_relevant("ITC", "Switch to digital: citcom results") and not radar.is_relevant("LT", "Sunil bags order")


def _gate_world(heads_fn, require=True):
    sent, calls = [], []
    clk = [DAY.replace(hour=9, minute=20)]
    def heads(sym):
        calls.append(clk[0]); return heads_fn(len(calls))
    r = radar.Radar(UNI, send=lambda text, silent=False: sent.append(text), now_fn=lambda: clk[0], headlines=heads,
                    state_path=os.path.join(os.environ["DATA_DIR"], f"g{real_time.time()}.json"), require_catalyst=require)
    def push(h, m, cum, price=110.0):
        clk[0] = DAY.replace(hour=h, minute=m, second=30)
        r.on_tick(tick("T1", price, h, m, cum, s=20))
    return r, sent, calls, push


def test_no_news_no_alert_then_news_arrives():
    news = {"on": False}
    r, sent, calls, push = _gate_world(lambda n: ["Reliance bags Rs 900 crore order - X"] if news["on"] else [])
    push(9, 20, 600_000)
    assert not sent and "RELI" in r.state["nonews"] and r.state["nonews"]["RELI"]["n"] == 1 and len(calls) == 1
    push(9, 22, 700_000); assert len(calls) == 1                       # waiting period (3 min): no repeat lookups
    news["on"] = True
    push(9, 24, 900_000)                                               # >3 min later: re-check finds the catalyst
    assert len(sent) == 1 and "BIG MOVER: RELI" in sent[0] and "Big order" in sent[0]
    assert "price/volume trigger met 09:20, waited for news confirmation" in sent[0]   # delay is disclosed
    assert "RELI" not in r.state["nonews"] and "RELI" in r.state["alerted"]


def test_recheck_limit_and_failed_search_retries_sooner():
    r, sent, calls, push = _gate_world(lambda n: [])
    for i, (h, m) in enumerate([(9, 20), (9, 24), (9, 28), (9, 32), (9, 36)]):
        push(h, m, 600_000 + i * 50_000)
    assert len(calls) == 3 and not sent                                # only 3 attempts per stock
    r2, sent2, calls2, push2 = _gate_world(lambda n: None)             # None = search itself failed
    push2(9, 20, 600_000); assert r2.state["nonews"]["RELI"]["n"] == 0 and r2.state["nonews"]["RELI"]["failed"]
    push2(9, 21, 650_000); assert len(calls2) == 1                     # too soon (2 min wait)
    push2(9, 23, 700_000); assert len(calls2) == 2                     # retried after 2 minutes


def test_digest_lists_skipped_movers_and_gate_can_be_disabled():
    r, sent, calls, push = _gate_world(lambda n: [])
    push(9, 20, 600_000)
    d = r.digest()
    assert "0 alert(s)" in d and "RELI" in d and "+10.0%" in d and "no catalyst headline" in d
    r2, sent2, calls2, push2 = _gate_world(lambda n: [], require=False)   # RADAR_REQUIRE_CATALYST=0
    push2(9, 20, 600_000)
    assert len(sent2) == 1 and "BIG MOVER" in sent2[0] and "Catalyst:" not in sent2[0]


def test_fetch_headlines_freshness_relevance_and_failure():
    from email.utils import format_datetime
    from datetime import timezone
    now = datetime.now(timezone.utc)
    def item(title, hours_ago):
        return f"<item><title>{title}</title><pubDate>{format_datetime(now - timedelta(hours=hours_ago))}</pubDate></item>"
    xml = ("<rss><channel>" + item("ITC Q2 results: profit up - Pub", 3) + item("ITC old news - Pub", 30)
           + item("Unrelated company results - Pub", 2) + "<item><title>ITC undated - Pub</title></item>"
           + "</channel></rss>").encode()
    class R:
        content = xml
        def raise_for_status(self): pass
    orig = radar.requests.get; radar.requests.get = lambda *a, **k: R()
    try:
        assert radar.fetch_headlines("ITC") == ["ITC Q2 results: profit up - Pub"]   # fresh + relevant only
    finally:
        radar.requests.get = orig
    def boom(*a, **k): raise RuntimeError("blocked")
    radar.requests.get = boom
    try:
        assert radar.fetch_headlines("ITC") is None                                  # failure != "no news"
    finally:
        radar.requests.get = orig


def test_alert_explains_why_it_waited():
    sent = []
    clk = [DAY.replace(hour=10, minute=0)]
    r = radar.Radar(UNI, send=lambda text, silent=False: sent.append(text), now_fn=lambda: clk[0],
                    headlines=lambda s: ["Reliance Q2 results: profit jumps 18% - X"],
                    state_path=os.path.join(os.environ["DATA_DIR"], f"w{real_time.time()}.json"))
    avg, base = UNI["T1"]["avg_vol"], 10 * 60
    t0 = base + 20
    for step in range(0, 61):                  # 10:00 -> 10:30, ticks every 30 s
        m = base + step / 2
        if m <= t0:                            # up 2.5% but volume only at 2x normal pace: no acceleration
            cum = 2.0 * avg * _f(m)
        else:                                  # then the pace jumps to 6x normal
            cum = 2.0 * avg * _f(t0) + 6.0 * avg * (_f(m) - _f(t0))
        t = DAY.replace(hour=int(m // 60), minute=int(m % 60), second=int((m % 1) * 60))
        clk[0] = t
        r.on_tick({"_norm": True, "token": "T1", "price": 102.5, "ts": t, "cum_vol": cum, "vwap": 101.5, "day_open": 100.2})
    assert len(sent) == 1, sent
    assert "first above +2% at 10:00" in sent[0] and "held back by volume pace" in sent[0], sent[0]


def test_explain_why_breakout_engine_missed_it():
    groups = {}
    up = synth.make_symbol("UPT", kind="trend", base=100, seed=3)
    dn = synth.make_symbol("DWN", kind="down", base=100, seed=4)
    cheap = synth.make_symbol("CHP", kind="trend", base=10, seed=6)
    for df in (up, dn, cheap):
        df["turnover_cr"] = df["volume"] * df["close"] / 1e7
        groups[df["symbol"].iloc[0]] = df
    ctx = {"items": [{"symbol": "UPT", "tier": "A"}, {"symbol": "BIG", "tier": "B"}]}
    tag, bucket = radar.explain_miss(groups, ctx, "UPT", 4.0)
    assert tag.startswith("on watchlist (A)") and "outside entry zone" in tag
    tag, _ = radar.explain_miss(groups, ctx, "BIG", 10.8)
    assert f"past the +{config.MAX_DAY_CHANGE_PCT:g}% cap" in tag
    tag, _ = radar.explain_miss(groups, ctx, "CHP", 5.0)
    assert "price under" in tag, tag
    tag, _ = radar.explain_miss(groups, ctx, "NOHIST", 5.0)
    assert "under 200 days" in tag
    assert radar.explain_miss(groups, None, "UPT", 5.0)[0] == "watchlist unknown"


def test_gate_reason_names_the_first_failed_filter():
    ok = dict(close=200.0, median_turnover_cr=20.0, sma50=190.0, sma200=170.0, sma50_slope_pct=1.0,
              dist_52w_pct=5.0, dist_pivot_pct=3.0, max_jump_pct=8.0, yday_chg_pct=1.0)
    assert radar.gate_reason(ok) is None
    cases = [("close", 30.0, "price under"), ("median_turnover_cr", 1.0, "low traded value"),
             ("close", 180.0, "below 50-day average"), ("sma50", 160.0, "50-day below 200-day"),
             ("sma50_slope_pct", -0.5, "50-day average falling"), ("dist_52w_pct", 31.0, "31% below 52-week high"),
             ("dist_pivot_pct", 24.0, "24% below 20-day high"), ("max_jump_pct", 50.0, "unexplained price jump"),
             ("yday_chg_pct", 13.0, "already +12% yesterday")]
    for key, val, expect in cases:
        f = dict(ok); f[key] = val
        assert expect in (radar.gate_reason(f) or ""), (key, val, radar.gate_reason(f))


def test_digest_shows_reason_per_mover_and_a_tally():
    r, sent, calls, push = _gate_world(lambda n: [])
    push(9, 20, 600_000)
    tags = {"RELI": ("not on watchlist (24% below 20-day high)", "not on watchlist: N% below 20-day high")}
    d = r.digest(lambda sym, chg: tags[sym])
    assert "RELI +10.0% [not on watchlist (24% below 20-day high)]" in d
    assert "Why the breakout engine missed all 1: 1 × not on watchlist: N% below 20-day high" in d
    assert len(d) < 3500


def _fake_world(feed_on):
    st = dict(T=DAY.replace(hour=8, minute=55), streams=[], sent=[], wall=1000.0)
    config.now_ist = lambda: st["T"]
    def sleep(sec):
        st["T"] += timedelta(seconds=sec); st["wall"] += sec
        for s in st["streams"]:
            if s.alive and feed_on(st["T"]) and st["T"].time() >= datetime(2026, 1, 1, 9, 16).time():
                s.on_tick(tick("T1", 101.0, st["T"].hour, st["T"].minute, 1000, s=st["T"].second))
    shim = types.SimpleNamespace(sleep=sleep, time=lambda: st["wall"])
    radar.time = shim
    class FC:
        def login(self): pass
    class FS:
        def __init__(self, c, t, on): self.on_tick, self._a = on, False; st["streams"].append(self)
        def start(self): self._a = True
        @property
        def alive(self): return self._a
        def stop(self): self._a = False
    broker.make_client = lambda: FC(); broker.make_stream = lambda c, t, on: FS(c, t, on)
    broker.load_token_map = lambda force=False: {"RELI": "T1", "SLOW": "T2"}
    notify.send = lambda text, silent=False: st["sent"].append(text); radar.notify.send = notify.send
    # a tiny store so build_universe has something to chew on
    s = synth.make_symbol("RELI", base=100, seed=1); s2 = synth.make_symbol("SLOW", base=200, seed=2)
    store = pd.concat([s, s2], ignore_index=True); store["turnover_cr"] = 50.0
    radar.daily_store.load = lambda: store
    return st


def test_supervisor_done_holiday_timeout():
    st = _fake_world(lambda now: True)
    assert radar.run() == "done" and any("Catalyst radar on" in m for m in st["sent"])
    st = _fake_world(lambda now: False)
    assert radar.run() == "holiday" and len(st["streams"]) == 3
    st = _fake_world(lambda now: True)
    assert radar.run(max_minutes=30) == "timeout"


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)
