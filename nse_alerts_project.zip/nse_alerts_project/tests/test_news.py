import json, os, sys, tempfile
from datetime import datetime, timedelta
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.environ["DATA_DIR"] = tempfile.mkdtemp()
from nse_alerts import config, news

IST = config.IST
NOW = datetime(2026, 11, 10, 6, 5, tzinfo=IST)          # a Tuesday morning


def test_classification_picks_catalysts_and_ignores_noise():
    yes = [
        ("Bagging/Receiving of orders/contracts", "The Company has received an order worth Rs 450 crore from Railways", "Big order"),
        ("Outcome of Board Meeting", "Board approved the unaudited financial results for the quarter ended 30 Sep 2026", "Results"),
        ("Financial Results", "", "Results"),
        ("Issue of bonus shares", "Board recommends bonus issue in ratio 1:1", "Bonus / split"),
        ("Buy back of shares", "", "Buyback"),
        ("Acquisition", "Company to acquire 100% stake in ABC Ltd", "Merger / deal"),
        ("USFDA approval received", "", "Approval"),
    ]
    for subject, text, cat in yes:
        got = news.classify_announcement(subject, text)
        assert got and got[0] == cat, (subject, got)
    no = [("Newspaper Publication", "financial results published"), ("Intimation of Board Meeting", "to consider results"),
          ("Trading Window", ""), ("Analyst / Investor Meet - Intimation", ""), ("Appointment of Director", ""),
          ("Order cancelled", "")]
    for subject, text in no:
        assert news.classify_announcement(subject, text) is None, subject
    assert news.classify_announcement("Receipt of order", "order terminated by the customer") is None   # cancellations ignored
    assert news.order_value_cr("orders worth Rs. 1,250 crore and ₹ 50 lakh") == 1250
    assert news.order_value_cr("INR 2 billion contract") == 200 and news.order_value_cr("no money") is None


def test_last_close_handles_weekends_and_time_of_day():
    f = lambda y, m, d, h, mi: news.last_close(datetime(y, m, d, h, mi, tzinfo=IST))
    assert f(2026, 11, 9, 6, 5) == datetime(2026, 11, 6, 15, 30, tzinfo=IST)     # Monday morning -> Friday close
    assert f(2026, 11, 10, 10, 0) == datetime(2026, 11, 9, 15, 30, tzinfo=IST)   # Tuesday during market
    assert f(2026, 11, 10, 16, 0) == datetime(2026, 11, 10, 15, 30, tzinfo=IST)  # Tuesday evening -> today's close
    assert f(2026, 11, 7, 12, 0) == datetime(2026, 11, 6, 15, 30, tzinfo=IST)    # Saturday -> Friday close


def test_build_watch_scores_merges_maps_and_expires():
    since = news.last_close(NOW)                                   # Mon 9 Nov 15:30
    after_close = datetime(2026, 11, 9, 18, 0, tzinfo=IST)
    anns = [
        dict(source="NSE", symbol="EMCURE", name="Emcure", subject="Outcome of Board Meeting",
             text="approved unaudited financial results for the quarter", ts=after_close),
        dict(source="NSE", symbol="EMCURE", name="Emcure", subject="Bagging/Receiving of orders/contracts",
             text="order worth Rs 300 crore", ts=after_close + timedelta(minutes=30)),
        dict(source="BSE", symbol=None, name="Tata Motors Ltd.", subject="Acquisition", text="to acquire company", ts=after_close),
        dict(source="BSE", symbol=None, name="Unknown Widgets Pvt Ltd", subject="Buy back", text="", ts=after_close),
        dict(source="NSE", symbol="OLDCO", name="Old", subject="Financial Results", text="", ts=since - timedelta(hours=3)),
        dict(source="NSE", symbol="NOISE", name="x", subject="Trading Window", text="", ts=after_close),
    ]
    nm = {news.normalize_name("TATA MOTORS LIMITED"): "TATAMOTORS"}
    items, st = news.build_watch(anns, nm, NOW, since)
    assert set(items) == {"EMCURE", "TATAMOTORS"} and st["unmapped"] == 1 and st["catalysts"] == 4
    e = items["EMCURE"]
    assert e["cats"] == ["Big order", "Results"] and e["score"] == 5.0           # 3 base +1 (>=100cr) +1 fresh
    assert "Bagging" in e["subject"] and e["amount_cr"] == 300
    assert items["TATAMOTORS"]["score"] == 3.0                                    # deal 2 + fresh 1
    # merge with existing entries; entries older than the cut-off expire
    old = {"STALE": dict(cats=["Results"], subject="x", ts=(since - timedelta(hours=5)).isoformat(), score=4.0)}
    items2, _ = news.build_watch([], nm, NOW, since, existing={**items, **old})
    assert "STALE" not in items2 and "EMCURE" in items2
    assert news.normalize_name("Larsen & Toubro Ltd.") == news.normalize_name("LARSEN AND TOUBRO LIMITED")


class FakeResp:
    def __init__(self, payload=None, status=200): self._p, self.status_code = payload, status
    def raise_for_status(self):
        if self.status_code >= 400:
            import requests
            raise requests.HTTPError(f"HTTP {self.status_code}", response=self)
    def json(self): return self._p


def test_fetchers_parse_realistic_payloads():
    seen = []
    class FakeSession:
        def __init__(self): self.headers = {}
        def get(self, url, **k):
            seen.append(url)
            if url.endswith("corporate-announcements"):
                return FakeResp([{"symbol": "EMCURE", "desc": "Outcome of Board Meeting", "sm_name": "Emcure Pharma",
                                  "attchmntText": "approved financial results", "an_dt": "09-Nov-2026 18:05:12"}])
            return FakeResp({})
    orig = news.requests.Session; news.requests.Session = FakeSession
    try:
        a = news.fetch_nse(news.last_close(NOW), NOW)
    finally:
        news.requests.Session = orig
    assert a[0]["symbol"] == "EMCURE" and a[0]["ts"] == datetime(2026, 11, 9, 18, 5, 12, tzinfo=IST)
    assert seen[0].startswith("https://www.nseindia.com") and any("corporate-announcements" in u for u in seen)

    since = news.last_close(NOW)
    pages = {1: [{"SLONGNAME": "Emcure Pharmaceuticals Ltd", "NEWSSUB": "Emcure - Results", "HEADLINE": "Financial results",
                  "NEWS_DT": "2026-11-09T18:05:12.113", "MORE": ""}],
             2: [{"SLONGNAME": "Old Co", "NEWSSUB": "x", "NEWS_DT": "2026-11-09T09:00:00"}], 3: [{"never": "reached"}]}
    calls = []
    def fake_get(url, params=None, **k):
        calls.append(params["pageno"]); return FakeResp({"Table": pages.get(params["pageno"], [])})
    orig = news.requests.get; news.requests.get = fake_get
    try:
        b = news.fetch_bse(since, NOW)
    finally:
        news.requests.get = orig
    assert len(b) == 1 and b[0]["name"].startswith("Emcure") and calls == [1, 2]      # stops at the first old page
    items, _ = news.build_watch(b, {news.normalize_name("Emcure Pharmaceuticals Limited"): "EMCURE"}, NOW, since)
    assert "EMCURE" in items


def test_collect_falls_back_and_reports_failure():
    path = os.path.join(config.DATA_DIR, "w.json")
    good = [dict(source="BSE", symbol=None, name="Emcure Pharmaceuticals Ltd", subject="Financial Results", text="",
                 ts=datetime(2026, 11, 9, 18, 0, tzinfo=IST))]
    def boom(since, now): raise RuntimeError("blocked: HTTP 403")
    nm = {news.normalize_name("Emcure Pharmaceuticals Limited"): "EMCURE"}
    r = news.collect(NOW, fetchers=[("NSE", boom), ("BSE", lambda s, n: good)], name_map=nm, path=path)
    assert r["ok"] and r["source"] == "BSE" and "NSE" in r["errors"] and "EMCURE" in r["watch"]
    assert "EMCURE" in news.load_watch(path)                                        # persisted for the live engine
    r = news.collect(NOW, fetchers=[("NSE", boom), ("BSE", boom)], name_map=nm, path=path)
    assert r["ok"] is False and set(r["errors"]) == {"NSE", "BSE"} and "EMCURE" in r["watch"]   # keeps the old list


def test_diagnose_prints_a_clear_verdict(capsys=None):
    import io, contextlib
    news.fetch_nse = lambda s, n: (_ for _ in ()).throw(RuntimeError("HTTP 403 Forbidden"))
    news.fetch_bse = lambda s, n: [dict(source="BSE", symbol=None, name="X Ltd", subject="Financial Results", text="",
                                        ts=datetime(2026, 11, 9, 18, 0, tzinfo=IST))]
    news.load_name_map = lambda force=False: {}
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        news.diagnose()
    out = buf.getvalue()
    assert "NOT reachable" in out and "catalysts by type: {'Results': 1}" in out and "at least one feed works" in out


if __name__ == "__main__":
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            f(); print("PASS", n)
